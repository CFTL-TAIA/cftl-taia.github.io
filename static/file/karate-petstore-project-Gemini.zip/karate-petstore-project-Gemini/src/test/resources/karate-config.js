function fn() {
  var env = karate.env || 'dev';
  var config = {};
  if (env == 'dev') {
    config.baseUrl = 'https://petstore.swagger.io/v2';
  } else if (env == 'prod') {
    config.baseUrl = 'https://petstore.swagger.io/v2';
  }
  karate.log('Environment:', env);
  return config;
}
