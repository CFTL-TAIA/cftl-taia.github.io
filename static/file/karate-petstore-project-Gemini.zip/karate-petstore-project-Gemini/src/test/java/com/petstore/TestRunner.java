package com.petstore;

import com.intuit.karate.junit5.Karate;

class TestRunner {

    @Karate.Test
    Karate runFolders() {
        return Karate.run(
                "classpath:features/pet",
                "classpath:features/store",
                "classpath:features/user"
        );
    }

    @Karate.Test
    Karate runFiles() {
        return Karate.run(
                "classpath:features/pet/petmanagement.feature",
                "classpath:features/store/storemanagement.feature",
                "classpath:features/user/usermanagement.feature"
        );
    }
}
